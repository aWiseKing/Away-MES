create definer = root@localhost view aw_detailsoftooldelivery as
select `away1`.`aw_tooloutbound`.`id`                         AS `id`,
       `away1`.`aw_tooloutbound`.`deliveryNoteID`             AS `deliveryNoteID`,
       `away1`.`aw_tooloutbound`.`toolInformationID`          AS `toolInformationID`,
       `away1`.`aw_tooloutbound`.`outboundQuantity`           AS `outboundQuantity`,
       `away1`.`aw_tooloutbound`.`newAndOldTypes`             AS `newAndOldTypes`,
       `away1`.`aw_tooloutbound`.`materialRequisition`        AS `materialRequisition`,
       `away1`.`aw_tooloutbound`.`notes`                      AS `notes`,
       `away1`.`aw_basictoolinformation`.`name`               AS `name`,
       `away1`.`aw_basictoolinformation`.`typeName`           AS `typeName`,
       `away1`.`aw_basictoolinformation`.`specificationsType` AS `specificationsType`,
       `away1`.`aw_basictoolinformation`.`specificationModel` AS `specificationModel`,
       `away1`.`aw_basictoolinformation`.`uint`               AS `uint`
from (`away1`.`aw_tooloutbound` join `away1`.`aw_basictoolinformation`
      on ((`away1`.`aw_tooloutbound`.`toolInformationID` = `away1`.`aw_basictoolinformation`.`id`)));

-- comment on column aw_detailsoftooldelivery.id not supported: 刀具出库id

-- comment on column aw_detailsoftooldelivery.deliveryNoteID not supported: 出库单编号

-- comment on column aw_detailsoftooldelivery.toolInformationID not supported: 刀具基本信息编号

-- comment on column aw_detailsoftooldelivery.outboundQuantity not supported: 出库数量

-- comment on column aw_detailsoftooldelivery.newAndOldTypes not supported: 新旧类型

-- comment on column aw_detailsoftooldelivery.materialRequisition not supported: 领用用途

-- comment on column aw_detailsoftooldelivery.notes not supported: 备注

-- comment on column aw_detailsoftooldelivery.name not supported: 刀具名称

-- comment on column aw_detailsoftooldelivery.typeName not supported: 类别名称

-- comment on column aw_detailsoftooldelivery.specificationsType not supported: 规格类型

-- comment on column aw_detailsoftooldelivery.specificationModel not supported: 规格型号

-- comment on column aw_detailsoftooldelivery.uint not supported: 计量单位

