create definer = root@localhost view aw_detaildlvrycsmtmtls as
select `away1`.`aw_dlvrycsmtmtls`.`id`                      AS `id`,
       `away1`.`aw_dlvrycsmtmtls`.`deliverynotesID`         AS `deliverynotesID`,
       `away1`.`aw_dlvrycsmtmtls`.`materialID`              AS `materialID`,
       `away1`.`aw_basicinformationofmaterials`.`name`      AS `materialName`,
       `away1`.`aw_productiontasks`.`productionTasksFormID` AS `productionTasksFormID`,
       `away1`.`aw_dlvrycsmtmtls`.`productionTasksID`       AS `productionTasksID`,
       `away1`.`aw_dlvrycsmtmtls`.`processingTechnologyID`  AS `processingTechnologyID`,
       `away1`.`aw_processrequirementmateriallist`.`id`     AS `prmID`,
       `away1`.`aw_dlvrycsmtmtls`.`outboundQuantity`        AS `outboundQuantity`,
       `away1`.`aw_dlvrycsmtmtls`.`notes`                   AS `notes`
from (((`away1`.`aw_dlvrycsmtmtls` join `away1`.`aw_basicinformationofmaterials`
        on ((`away1`.`aw_dlvrycsmtmtls`.`materialID` =
             `away1`.`aw_basicinformationofmaterials`.`id`))) join `away1`.`aw_processrequirementmateriallist`
       on ((`away1`.`aw_dlvrycsmtmtls`.`processingTechnologyID` =
            `away1`.`aw_processrequirementmateriallist`.`processingTechnologyID`))) join `away1`.`aw_productiontasks`
      on ((`away1`.`aw_dlvrycsmtmtls`.`productionTasksID` = `away1`.`aw_productiontasks`.`id`)));

-- comment on column aw_detaildlvrycsmtmtls.id not supported: id

-- comment on column aw_detaildlvrycsmtmtls.deliverynotesID not supported: 出库单编号

-- comment on column aw_detaildlvrycsmtmtls.materialID not supported: 材料基础信息编号

-- comment on column aw_detaildlvrycsmtmtls.materialName not supported: 材料名称

-- comment on column aw_detaildlvrycsmtmtls.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_detaildlvrycsmtmtls.productionTasksID not supported: 任务编号

-- comment on column aw_detaildlvrycsmtmtls.processingTechnologyID not supported: 工艺编号

-- comment on column aw_detaildlvrycsmtmtls.prmID not supported: id

-- comment on column aw_detaildlvrycsmtmtls.outboundQuantity not supported: 出库数量

-- comment on column aw_detaildlvrycsmtmtls.notes not supported: 备注

