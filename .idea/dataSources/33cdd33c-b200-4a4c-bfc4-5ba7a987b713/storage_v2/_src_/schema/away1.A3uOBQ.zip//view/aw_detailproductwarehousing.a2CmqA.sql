create definer = root@localhost view aw_detailproductwarehousing as
select `away1`.`aw_productstorage`.`id`                          AS `id`,
       `away1`.`aw_productstorage`.`warehouseEntryID`            AS `warehouseEntryID`,
       `away1`.`aw_productstorage`.`productID`                   AS `productID`,
       `away1`.`aw_productstorage`.`receiptQuantity`             AS `receiptQuantity`,
       `away1`.`aw_productstorage`.`FinishedProductInspectionID` AS `FinishedProductInspectionID`,
       `away1`.`aw_finishedproductinspection`.`testResult`       AS `testResult`,
       `away1`.`aw_productstorage`.`notes`                       AS `notes`
from (`away1`.`aw_productstorage` left join `away1`.`aw_finishedproductinspection`
      on ((`away1`.`aw_productstorage`.`FinishedProductInspectionID` = `away1`.`aw_finishedproductinspection`.`id`)));

-- comment on column aw_detailproductwarehousing.id not supported: id

-- comment on column aw_detailproductwarehousing.warehouseEntryID not supported: 产品入库单编号

-- comment on column aw_detailproductwarehousing.productID not supported: 产品图号

-- comment on column aw_detailproductwarehousing.receiptQuantity not supported: 入库数量

-- comment on column aw_detailproductwarehousing.FinishedProductInspectionID not supported: 成品检验编号

-- comment on column aw_detailproductwarehousing.testResult not supported: 检测结果

-- comment on column aw_detailproductwarehousing.notes not supported: 备注

