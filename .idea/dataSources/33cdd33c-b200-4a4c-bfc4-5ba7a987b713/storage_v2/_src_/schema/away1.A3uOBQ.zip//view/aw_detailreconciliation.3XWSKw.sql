create definer = root@localhost view aw_detailreconciliation as
select `away1`.`aw_reconciliation`.`id`                       AS `id`,
       `away1`.`aw_reconciliation`.`statementOfAccountID`     AS `statementOfAccountID`,
       `away1`.`aw_reconciliation`.`saleorderID`              AS `saleorderID`,
       `away1`.`aw_basicorderinformation`.`money`             AS `money`,
       `away1`.`aw_basicorderinformation`.`name`              AS `name`,
       `away1`.`aw_basicorderinformation`.`productName`       AS `productName`,
       `away1`.`aw_basicorderinformation`.`number`            AS `number`,
       `away1`.`aw_reconciliation`.`numberOfProductsSupplied` AS `numberOfProductsSupplied`,
       `away1`.`aw_reconciliation`.`orderAmount`              AS `orderAmount`,
       `away1`.`aw_reconciliation`.`amountDue`                AS `amountDue`,
       `away1`.`aw_reconciliation`.`outOfPocketAmount`        AS `outOfPocketAmount`,
       `away1`.`aw_reconciliation`.`unpaidAmount`             AS `unpaidAmount`,
       `away1`.`aw_reconciliation`.`customerPrice`            AS `customerPrice`,
       `away1`.`aw_reconciliation`.`processPrice`             AS `processPrice`,
       `away1`.`aw_reconciliation`.`invoicePrice`             AS `invoicePrice`,
       `away1`.`aw_reconciliation`.`notes`                    AS `notes`,
       `away1`.`aw_reconciliation`.`status`                   AS `status`
from (`away1`.`aw_reconciliation` join `away1`.`aw_basicorderinformation`
      on ((`away1`.`aw_reconciliation`.`saleorderID` = `away1`.`aw_basicorderinformation`.`id`)));

-- comment on column aw_detailreconciliation.id not supported: 对账id

-- comment on column aw_detailreconciliation.statementOfAccountID not supported: 对账单Id

-- comment on column aw_detailreconciliation.saleorderID not supported: 订单id

-- comment on column aw_detailreconciliation.money not supported: 合同金额

-- comment on column aw_detailreconciliation.name not supported: 实体姓名

-- comment on column aw_detailreconciliation.productName not supported: 产品名称

-- comment on column aw_detailreconciliation.number not supported: 需求数量#要求大于0#

-- comment on column aw_detailreconciliation.numberOfProductsSupplied not supported: 以供产品数

-- comment on column aw_detailreconciliation.orderAmount not supported: 订单金额

-- comment on column aw_detailreconciliation.amountDue not supported: 应付金额

-- comment on column aw_detailreconciliation.outOfPocketAmount not supported: 实付金额

-- comment on column aw_detailreconciliation.unpaidAmount not supported: 未付金额

-- comment on column aw_detailreconciliation.customerPrice not supported: 客户价格

-- comment on column aw_detailreconciliation.processPrice not supported: 工艺价格

-- comment on column aw_detailreconciliation.invoicePrice not supported: 发票价格

-- comment on column aw_detailreconciliation.notes not supported: 备注

-- comment on column aw_detailreconciliation.status not supported: 是否通过

