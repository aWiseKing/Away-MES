create definer = root@localhost view aw_basictoolinformation as
select `away1`.`aw_toolinformation`.`id`                AS `id`,
       `away1`.`aw_toolinformation`.`name`              AS `name`,
       `away1`.`aw_toolinformation`.`typeID`            AS `typeID`,
       `away1`.`aw_toolinformation`.`specificationsID`  AS `specificationsID`,
       `away1`.`aw_toolinformation`.`unitID`            AS `unitID`,
       `away1`.`aw_toolinformation`.`notes`             AS `notes`,
       `away1`.`aw_toolclassification`.`name`           AS `typeName`,
       `away1`.`aw_units`.`unit`                        AS `uint`,
       `away1`.`aw_specifications`.`type`               AS `specificationsType`,
       `away1`.`aw_specifications`.`specificationModel` AS `specificationModel`
from (((`away1`.`aw_toolinformation` join `away1`.`aw_toolclassification`
        on ((`away1`.`aw_toolinformation`.`typeID` = `away1`.`aw_toolclassification`.`id`))) join `away1`.`aw_units`
       on ((`away1`.`aw_toolinformation`.`unitID` = `away1`.`aw_units`.`id`))) join `away1`.`aw_specifications`
      on ((`away1`.`aw_toolinformation`.`specificationsID` = `away1`.`aw_specifications`.`id`)));

-- comment on column aw_basictoolinformation.id not supported: 刀具编号

-- comment on column aw_basictoolinformation.name not supported: 刀具名称

-- comment on column aw_basictoolinformation.typeID not supported: 刀具分类

-- comment on column aw_basictoolinformation.specificationsID not supported: 刀具规格

-- comment on column aw_basictoolinformation.unitID not supported: 计量单位id

-- comment on column aw_basictoolinformation.notes not supported: 备注信息

-- comment on column aw_basictoolinformation.typeName not supported: 类别名称

-- comment on column aw_basictoolinformation.uint not supported: 计量单位

-- comment on column aw_basictoolinformation.specificationsType not supported: 规格类型

-- comment on column aw_basictoolinformation.specificationModel not supported: 规格型号

