create definer = root@localhost view aw_basicorderinformation as
select `away1`.`aw_saleorder`.`id`     AS `id`,
       `away1`.`aw_saleorder`.`number` AS `number`,
       `away1`.`aw_partner`.`name`     AS `name`,
       `away1`.`aw_contract`.`money`   AS `money`,
       `away1`.`aw_product`.`name`     AS `productName`
from (((`away1`.`aw_saleorder` join `away1`.`aw_partner`
        on ((`away1`.`aw_saleorder`.`customerID` = `away1`.`aw_partner`.`id`))) join `away1`.`aw_product`
       on ((`away1`.`aw_saleorder`.`productID` = `away1`.`aw_product`.`id`))) join `away1`.`aw_contract`
      on ((`away1`.`aw_saleorder`.`contractID` = `away1`.`aw_contract`.`id`)));

-- comment on column aw_basicorderinformation.id not supported: 订单id#日期+编号#

-- comment on column aw_basicorderinformation.number not supported: 需求数量#要求大于0#

-- comment on column aw_basicorderinformation.name not supported: 实体姓名

-- comment on column aw_basicorderinformation.money not supported: 合同金额

-- comment on column aw_basicorderinformation.productName not supported: 产品名称

