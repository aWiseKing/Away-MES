create definer = root@localhost view aw_detailsoftoolstorage as
select `away1`.`aw_toolstorage`.`id`                               AS `id`,
       `away1`.`aw_toolstorage`.`warehouseEntryID`                 AS `warehouseEntryID`,
       `away1`.`aw_toolstorage`.`receiptInvoiceID`                 AS `receiptInvoiceID`,
       `away1`.`aw_toolstorage`.`toolInformationID`                AS `toolInformationID`,
       `away1`.`aw_toolstorage`.`receiptQuantity`                  AS `receiptQuantity`,
       `away1`.`aw_toolstorage`.`notes`                            AS `notes`,
       `away1`.`aw_receiptinvoice`.`invoiceTaxRate`                AS `invoiceTaxRate`,
       `away1`.`aw_receiptinvoice`.`invoiceType`                   AS `invoiceType`,
       `away1`.`aw_receiptinvoice`.`purchaseUnitPriceExcludingTax` AS `purchaseUnitPriceExcludingTax`,
       `away1`.`aw_receiptinvoice`.`purchaseUnitPriceIncludingTax` AS `purchaseUnitPriceIncludingTax`,
       `away1`.`aw_basictoolinformation`.`name`                    AS `name`,
       `away1`.`aw_basictoolinformation`.`typeName`                AS `typeName`,
       `away1`.`aw_basictoolinformation`.`specificationsType`      AS `specificationsType`,
       `away1`.`aw_basictoolinformation`.`specificationModel`      AS `specificationModel`,
       `away1`.`aw_basictoolinformation`.`uint`                    AS `uint`
from ((`away1`.`aw_toolstorage` join `away1`.`aw_basictoolinformation`
       on ((`away1`.`aw_toolstorage`.`toolInformationID` =
            `away1`.`aw_basictoolinformation`.`id`))) join `away1`.`aw_receiptinvoice`
      on ((`away1`.`aw_toolstorage`.`receiptInvoiceID` = `away1`.`aw_receiptinvoice`.`receiptInvoiceID`)));

-- comment on column aw_detailsoftoolstorage.id not supported: 刀具入库id

-- comment on column aw_detailsoftoolstorage.warehouseEntryID not supported: 入库单编号

-- comment on column aw_detailsoftoolstorage.receiptInvoiceID not supported: 发票信息编号

-- comment on column aw_detailsoftoolstorage.toolInformationID not supported: 刀具基本信息

-- comment on column aw_detailsoftoolstorage.receiptQuantity not supported: 入库数量

-- comment on column aw_detailsoftoolstorage.notes not supported: 备注

-- comment on column aw_detailsoftoolstorage.invoiceTaxRate not supported: 发票税率

-- comment on column aw_detailsoftoolstorage.invoiceType not supported: 发票类型

-- comment on column aw_detailsoftoolstorage.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column aw_detailsoftoolstorage.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column aw_detailsoftoolstorage.name not supported: 刀具名称

-- comment on column aw_detailsoftoolstorage.typeName not supported: 类别名称

-- comment on column aw_detailsoftoolstorage.specificationsType not supported: 规格类型

-- comment on column aw_detailsoftoolstorage.specificationModel not supported: 规格型号

-- comment on column aw_detailsoftoolstorage.uint not supported: 计量单位

