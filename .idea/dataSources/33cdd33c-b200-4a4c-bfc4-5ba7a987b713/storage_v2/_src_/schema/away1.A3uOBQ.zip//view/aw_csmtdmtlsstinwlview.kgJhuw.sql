create definer = root@localhost view aw_csmtdmtlsstinwlview as
select `away1`.`aw_csmtdmtlsstinwlist`.`warehouseEntryID` AS `warehouseEntryID`,
       `away1`.`aw_warehousing`.`warehousingDate`         AS `warehousingDate`,
       `away1`.`aw_warehousing`.`creator`                 AS `creator`,
       `away1`.`aw_warehousing`.`acceptedBy`              AS `acceptedBy`,
       `away1`.`aw_warehousing`.`warehouseKeeper`         AS `warehouseKeeper`,
       `away1`.`aw_warehousing`.`operator`                AS `operator`,
       `away1`.`aw_warehousing`.`notes`                   AS `notes`,
       `away1`.`aw_warehousing`.`status`                  AS `status`
from (`away1`.`aw_csmtdmtlsstinwlist` left join `away1`.`aw_warehousing`
      on ((`away1`.`aw_csmtdmtlsstinwlist`.`warehouseEntryID` = `away1`.`aw_warehousing`.`warehouseEntryID`)));

-- comment on column aw_csmtdmtlsstinwlview.warehouseEntryID not supported: 入库单编号

-- comment on column aw_csmtdmtlsstinwlview.warehousingDate not supported: 入库日期

-- comment on column aw_csmtdmtlsstinwlview.creator not supported: 制单人

-- comment on column aw_csmtdmtlsstinwlview.acceptedBy not supported: 验收人

-- comment on column aw_csmtdmtlsstinwlview.warehouseKeeper not supported: 库管员

-- comment on column aw_csmtdmtlsstinwlview.operator not supported: 经办人

-- comment on column aw_csmtdmtlsstinwlview.notes not supported: 备注

-- comment on column aw_csmtdmtlsstinwlview.status not supported: 状态

