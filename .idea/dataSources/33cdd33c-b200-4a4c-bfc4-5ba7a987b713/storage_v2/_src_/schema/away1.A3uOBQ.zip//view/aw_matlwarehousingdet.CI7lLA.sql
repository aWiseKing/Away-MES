create definer = root@localhost view aw_matlwarehousingdet as
select `away1`.`aw_localmaterialwarehousing`.`id`                    AS `id`,
       `away1`.`aw_localmaterialwarehousing`.`warehouseEntryID`      AS `warehouseEntryID`,
       `away1`.`aw_localmaterialwarehousing`.`materialSubscription`  AS `materialSubscription`,
       `away1`.`aw_localmaterialwarehousing`.`materialID`            AS `materialID`,
       `away1`.`aw_basicinformationofmaterials`.`name`               AS `name`,
       `away1`.`aw_basicinformationofmaterials`.`typeName`           AS `typeName`,
       `away1`.`aw_basicinformationofmaterials`.`specificationsType` AS `specificationsType`,
       `away1`.`aw_basicinformationofmaterials`.`specificationModel` AS `specificationModel`,
       `away1`.`aw_basicinformationofmaterials`.`materialDensity`    AS `materialDensity`,
       `away1`.`aw_localmaterialwarehousing`.`receiptInvoiceID`      AS `receiptInvoiceID`,
       `away1`.`aw_receiptinvoice`.`invoiceType`                     AS `invoiceType`,
       `away1`.`aw_receiptinvoice`.`invoiceTaxRate`                  AS `invoiceTaxRate`,
       `away1`.`aw_receiptinvoice`.`purchaseUnitPriceExcludingTax`   AS `purchaseUnitPriceExcludingTax`,
       `away1`.`aw_receiptinvoice`.`purchaseUnitPriceIncludingTax`   AS `purchaseUnitPriceIncludingTax`,
       `away1`.`aw_localmaterialwarehousing`.`receiptQuantity`       AS `receiptQuantity`,
       `away1`.`aw_localmaterialwarehousing`.`sampleURL`             AS `sampleURL`,
       `away1`.`aw_localmaterialwarehousing`.`notes`                 AS `notes`
from ((`away1`.`aw_localmaterialwarehousing` join `away1`.`aw_receiptinvoice`
       on ((`away1`.`aw_localmaterialwarehousing`.`receiptInvoiceID` =
            `away1`.`aw_receiptinvoice`.`receiptInvoiceID`))) join `away1`.`aw_basicinformationofmaterials`
      on ((`away1`.`aw_localmaterialwarehousing`.`materialID` = `away1`.`aw_basicinformationofmaterials`.`id`)));

-- comment on column aw_matlwarehousingdet.id not supported: id

-- comment on column aw_matlwarehousingdet.warehouseEntryID not supported: 入库单编号

-- comment on column aw_matlwarehousingdet.materialSubscription not supported: 申购材料编号

-- comment on column aw_matlwarehousingdet.materialID not supported: 材料基础信息编号

-- comment on column aw_matlwarehousingdet.name not supported: 材料名称

-- comment on column aw_matlwarehousingdet.typeName not supported: 类别名称

-- comment on column aw_matlwarehousingdet.specificationsType not supported: 规格类型

-- comment on column aw_matlwarehousingdet.specificationModel not supported: 规格型号

-- comment on column aw_matlwarehousingdet.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_matlwarehousingdet.receiptInvoiceID not supported: 发票信息编号

-- comment on column aw_matlwarehousingdet.invoiceType not supported: 发票类型

-- comment on column aw_matlwarehousingdet.invoiceTaxRate not supported: 发票税率

-- comment on column aw_matlwarehousingdet.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column aw_matlwarehousingdet.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column aw_matlwarehousingdet.receiptQuantity not supported: 入库数量

-- comment on column aw_matlwarehousingdet.sampleURL not supported: 附样

-- comment on column aw_matlwarehousingdet.notes not supported: 备注

