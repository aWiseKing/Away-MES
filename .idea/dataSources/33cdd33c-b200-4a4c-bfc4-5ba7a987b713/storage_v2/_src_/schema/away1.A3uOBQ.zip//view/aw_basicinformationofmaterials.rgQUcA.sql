create definer = root@localhost view aw_basicinformationofmaterials as
select `away1`.`aw_material`.`id`                       AS `id`,
       `away1`.`aw_material`.`name`                     AS `name`,
       `away1`.`aw_material`.`typeID`                   AS `typeID`,
       `away1`.`aw_material`.`specificationsID`         AS `specificationsID`,
       `away1`.`aw_material`.`materialDensity`          AS `materialDensity`,
       `away1`.`aw_material`.`notes`                    AS `notes`,
       `away1`.`aw_materialclassification`.`name`       AS `typeName`,
       `away1`.`aw_specifications`.`type`               AS `specificationsType`,
       `away1`.`aw_specifications`.`specificationModel` AS `specificationModel`
from ((`away1`.`aw_material` join `away1`.`aw_materialclassification` on ((`away1`.`aw_material`.`typeID` =
                                                                           `away1`.`aw_materialclassification`.`id`))) join `away1`.`aw_specifications`
      on ((`away1`.`aw_material`.`specificationsID` = `away1`.`aw_specifications`.`id`)));

-- comment on column aw_basicinformationofmaterials.id not supported: 材料编号

-- comment on column aw_basicinformationofmaterials.name not supported: 材料名称

-- comment on column aw_basicinformationofmaterials.typeID not supported: 材料分类

-- comment on column aw_basicinformationofmaterials.specificationsID not supported: 规格类型

-- comment on column aw_basicinformationofmaterials.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_basicinformationofmaterials.notes not supported: 备注信息

-- comment on column aw_basicinformationofmaterials.typeName not supported: 类别名称

-- comment on column aw_basicinformationofmaterials.specificationsType not supported: 规格类型

-- comment on column aw_basicinformationofmaterials.specificationModel not supported: 规格型号

