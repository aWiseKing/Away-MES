create definer = root@localhost view aw_salesorderdetails as
select `away2`.`aw_saleorder`.`id`                            AS `id`,
       `away2`.`aw_saleorder`.`createTime`                    AS `createTime`,
       `away2`.`aw_saleorder`.`createUserName`                AS `createUserName`,
       `away2`.`aw_saleorder`.`orderDate`                     AS `orderDate`,
       `away2`.`aw_saleorder`.`number`                        AS `number`,
       `away2`.`aw_saleorder`.`requiredDeliveryTime`          AS `requiredDeliveryTime`,
       `away2`.`aw_saleorder`.`iscustomersuppliedmaterials`   AS `iscustomersuppliedmaterials`,
       `away2`.`aw_saleorder`.`customersuppliedmaterialsID`   AS `customersuppliedmaterialsID`,
       `away2`.`aw_saleorder`.`state`                         AS `state`,
       `away2`.`aw_saleorder`.`note`                          AS `note`,
       `away2`.`aw_saleorder`.`isDel`                         AS `isDel`,
       `away2`.`aw_saleorder`.`customerID`                    AS `customerID`,
       `away2`.`aw_partner`.`name`                            AS `name`,
       `away2`.`aw_partner`.`nameAbbrevation`                 AS `nameAbbrevation`,
       `away2`.`aw_partner`.`unifiedCreditCode`               AS `unifiedCreditCode`,
       `away2`.`aw_saleorder`.`productID`                     AS `productID`,
       `away2`.`aw_product`.`name`                            AS `productName`,
       `away2`.`aw_product`.`drawingURL`                      AS `drawingURL`,
       `away2`.`aw_saleorder`.`contractID`                    AS `contractID`,
       `away2`.`aw_contract`.`money`                          AS `money`,
       `away2`.`aw_contract`.`contractURL`                    AS `contractURL`,
       `away2`.`aw_saleorder`.`invoiceID`                     AS `invoiceID`,
       `away2`.`aw_invoice`.`invoiceType`                     AS `invoiceType`,
       `away2`.`aw_invoice`.`invoiceCreateTime`               AS `invoiceCreateTime`,
       `away2`.`aw_invoice`.`invoiceNumer`                    AS `invoiceNumer`,
       `away2`.`aw_invoice`.`taxRate`                         AS `taxRate`,
       `away2`.`aw_invoice`.`taxation`                        AS `taxation`,
       `away2`.`aw_invoice`.`salesUnitPriceExcludingTax`      AS `salesUnitPriceExcludingTax`,
       `away2`.`aw_invoice`.`salesUnitPriceIncludingTax`      AS `salesUnitPriceIncludingTax`,
       `away2`.`aw_invoice`.`consumptionAmountExcludingTax`   AS `consumptionAmountExcludingTax`,
       `away2`.`aw_invoice`.`consumptionAmountIncludingTax`   AS `consumptionAmountIncludingTax`,
       `away2`.`aw_invoice`.`reconciliationDate`              AS `reconciliationDate`,
       `away2`.`aw_invoice`.`customerReconciliationPersonnel` AS `customerReconciliationPersonnel`
from ((((`away2`.`aw_saleorder` join `away2`.`aw_partner`
         on ((`away2`.`aw_saleorder`.`customerID` = `away2`.`aw_partner`.`id`))) join `away2`.`aw_product`
        on ((`away2`.`aw_saleorder`.`productID` = `away2`.`aw_product`.`id`))) join `away2`.`aw_contract`
       on ((`away2`.`aw_saleorder`.`contractID` = `away2`.`aw_contract`.`id`))) join `away2`.`aw_invoice`
      on ((`away2`.`aw_saleorder`.`invoiceID` = `away2`.`aw_invoice`.`id`)));

-- comment on column aw_salesorderdetails.id not supported: 订单id#日期+编号#

-- comment on column aw_salesorderdetails.createTime not supported: 销售单创建日期

-- comment on column aw_salesorderdetails.createUserName not supported: 创建人

-- comment on column aw_salesorderdetails.orderDate not supported: 下单日期

-- comment on column aw_salesorderdetails.number not supported: 需求数量#要求大于0#

-- comment on column aw_salesorderdetails.requiredDeliveryTime not supported: 要求交期#时间要晚于当前日期#

-- comment on column aw_salesorderdetails.iscustomersuppliedmaterials not supported: 客供材料否

-- comment on column aw_salesorderdetails.customersuppliedmaterialsID not supported: 客供材料编号

-- comment on column aw_salesorderdetails.state not supported: 当前订单状态#0为未发布 1为发布 2为暂停 3为完成 4为取消#

-- comment on column aw_salesorderdetails.note not supported: 备注

-- comment on column aw_salesorderdetails.isDel not supported: 删除否#0为存在 1为删除#

-- comment on column aw_salesorderdetails.customerID not supported: 客户信息

-- comment on column aw_salesorderdetails.name not supported: 实体姓名

-- comment on column aw_salesorderdetails.nameAbbrevation not supported: 实体简称

-- comment on column aw_salesorderdetails.unifiedCreditCode not supported: 社会统一信用代码

-- comment on column aw_salesorderdetails.productID not supported: 产品信息

-- comment on column aw_salesorderdetails.productName not supported: 产品名称

-- comment on column aw_salesorderdetails.drawingURL not supported: 产品图纸附件地址URL

-- comment on column aw_salesorderdetails.contractID not supported: 合同信息

-- comment on column aw_salesorderdetails.money not supported: 合同金额

-- comment on column aw_salesorderdetails.contractURL not supported: 合同附件地址URL

-- comment on column aw_salesorderdetails.invoiceID not supported: 发票信息

-- comment on column aw_salesorderdetails.invoiceType not supported: 开票类型

-- comment on column aw_salesorderdetails.invoiceCreateTime not supported: 开票日期

-- comment on column aw_salesorderdetails.invoiceNumer not supported: 开票数量

-- comment on column aw_salesorderdetails.taxRate not supported: 税率

-- comment on column aw_salesorderdetails.taxation not supported: 税费

-- comment on column aw_salesorderdetails.salesUnitPriceExcludingTax not supported: 销售单价(不含税)

-- comment on column aw_salesorderdetails.salesUnitPriceIncludingTax not supported: 销售单价(含税)

-- comment on column aw_salesorderdetails.consumptionAmountExcludingTax not supported: 销售金额(不含税)

-- comment on column aw_salesorderdetails.consumptionAmountIncludingTax not supported: 销售金额(含税)

-- comment on column aw_salesorderdetails.reconciliationDate not supported: 对账日期

-- comment on column aw_salesorderdetails.customerReconciliationPersonnel not supported: 客户对账人员

