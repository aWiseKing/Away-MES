create definer = root@localhost view aw_detailedrealtimeinventoryofmaterials as
select `away2`.`aw_localmaterials`.`id`                              AS `id`,
       `away2`.`aw_localmaterials`.`materialID`                      AS `materialID`,
       `away2`.`aw_localmaterials`.`number`                          AS `number`,
       `away2`.`aw_localmaterials`.`weight`                          AS `weight`,
       `away2`.`aw_basicinformationofmaterials`.`name`               AS `name`,
       `away2`.`aw_basicinformationofmaterials`.`typeName`           AS `typeName`,
       `away2`.`aw_basicinformationofmaterials`.`specificationsType` AS `specificationsType`,
       `away2`.`aw_basicinformationofmaterials`.`specificationModel` AS `specificationModel`,
       `away2`.`aw_basicinformationofmaterials`.`materialDensity`    AS `materialDensity`,
       `away2`.`aw_basicinformationofmaterials`.`notes`              AS `notes`
from (`away2`.`aw_basicinformationofmaterials` join `away2`.`aw_localmaterials`
      on ((`away2`.`aw_basicinformationofmaterials`.`id` = `away2`.`aw_localmaterials`.`materialID`)));

-- comment on column aw_detailedrealtimeinventoryofmaterials.id not supported: 材料库存id

-- comment on column aw_detailedrealtimeinventoryofmaterials.materialID not supported: 材料基本信息id

-- comment on column aw_detailedrealtimeinventoryofmaterials.number not supported: 材料库存数量

-- comment on column aw_detailedrealtimeinventoryofmaterials.weight not supported: 材料库存重量

-- comment on column aw_detailedrealtimeinventoryofmaterials.name not supported: 材料名称

-- comment on column aw_detailedrealtimeinventoryofmaterials.typeName not supported: 类别名称

-- comment on column aw_detailedrealtimeinventoryofmaterials.specificationsType not supported: 规格类型

-- comment on column aw_detailedrealtimeinventoryofmaterials.specificationModel not supported: 规格型号

-- comment on column aw_detailedrealtimeinventoryofmaterials.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_detailedrealtimeinventoryofmaterials.notes not supported: 备注信息

