create
    definer = root@localhost procedure p2()
begin
 declare stu_student int;
 select count(*) into stu_student from student;
 select stu_student;
end;

