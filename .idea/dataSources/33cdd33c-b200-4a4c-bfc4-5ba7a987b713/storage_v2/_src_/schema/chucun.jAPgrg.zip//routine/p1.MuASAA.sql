create
    definer = root@localhost procedure p1()
begin
    select count(*)from student;
end;

