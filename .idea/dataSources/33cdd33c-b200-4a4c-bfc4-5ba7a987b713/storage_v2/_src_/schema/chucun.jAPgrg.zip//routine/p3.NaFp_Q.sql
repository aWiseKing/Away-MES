create
    definer = root@localhost procedure p3(IN scrous int, OUT result varchar(10)) deterministic
begin

    if scrous>=85 then
        set result:='优秀';
    elseif scrous>=60 then
        set result:='及格';
    else
        set result:='不及格';


    end if ;

end;

