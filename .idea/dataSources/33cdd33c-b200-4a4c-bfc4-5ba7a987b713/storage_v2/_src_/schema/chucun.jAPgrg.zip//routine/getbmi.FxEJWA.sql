create
    definer = root@localhost function getbmi(tizhong float) returns varchar(10) deterministic
begin
     declare a varchar(10);
     if tizhong >=40 then set a:='三级肥胖';
      elseif tizhong >=35&&tizhong<40 then set a:='二级肥胖';
       elseif tizhong >=30&&tizhong<35 then set a:='一级肥胖';
        elseif tizhong >=25&&tizhong<30 then set a:='肥胖前期';
        elseif tizhong >=25 then set a:='超重';
        elseif tizhong<25&&tizhong>=18.5 then set a:='正常' ;

     else set a:='过轻';
     end if;
     return a;
end;

