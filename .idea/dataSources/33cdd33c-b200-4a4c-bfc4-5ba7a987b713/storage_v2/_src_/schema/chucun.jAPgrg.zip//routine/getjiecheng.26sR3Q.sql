create
    definer = root@localhost procedure getjiecheng(IN n int, OUT x int) deterministic
begin
    set x=1;
    while n>1 do
        set x=x*n;
        set n=n-1;
        end while;
end;

