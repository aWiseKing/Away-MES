create
    definer = root@localhost procedure p5(INOUT score double) deterministic
begin
    set score:=score*0.5;
end;

