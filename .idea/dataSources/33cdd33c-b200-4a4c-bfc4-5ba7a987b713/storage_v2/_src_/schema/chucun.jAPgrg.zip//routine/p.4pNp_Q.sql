create
    definer = root@localhost procedure p(IN scrous int) deterministic
begin
    declare result varchar(10);
    if scrous>=85 then
        set result:='优秀';
    elseif scrous>=60 then
        set result:='及格';
    else
        set result:='不及格';


    end if ;
    select result;
end;

