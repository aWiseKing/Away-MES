create definer = root@localhost view aw_detailedproductiontask as
select `away`.`aw_productiontasks`.`id`                            AS `id`,
       `away`.`aw_productiontasks`.`productionTasksFormID`         AS `productionTasksFormID`,
       `away`.`aw_productiontasks`.`serialNum`                     AS `serialNum`,
       `away`.`aw_productiontasks`.`outsourced`                    AS `outsourced`,
       `away`.`aw_productiontasks`.`notes`                         AS `notes`,
       `away`.`aw_productiontasks`.`status`                        AS `status`,
       `away`.`aw_productiontasks`.`processingTechnologyID`        AS `processingTechnologyID`,
       `away`.`aw_processingtechnology`.`founder`                  AS `founder`,
       `away`.`aw_productiontasks`.`saleOrderID`                   AS `saleOrderID`,
       `away`.`aw_salesorderdetails`.`createTime`                  AS `createTime`,
       `away`.`aw_salesorderdetails`.`createUserName`              AS `createUserName`,
       `away`.`aw_salesorderdetails`.`orderDate`                   AS `orderDate`,
       `away`.`aw_salesorderdetails`.`number`                      AS `number`,
       `away`.`aw_salesorderdetails`.`requiredDeliveryTime`        AS `requiredDeliveryTime`,
       `away`.`aw_salesorderdetails`.`iscustomersuppliedmaterials` AS `iscustomersuppliedmaterials`,
       `away`.`aw_salesorderdetails`.`customersuppliedmaterialsID` AS `customersuppliedmaterialsID`,
       `away`.`aw_salesorderdetails`.`state`                       AS `state`,
       `away`.`aw_salesorderdetails`.`nameAbbrevation`             AS `nameAbbrevation`,
       `away`.`aw_salesorderdetails`.`productName`                 AS `productName`
from ((`away`.`aw_productiontasks` join `away`.`aw_processingtechnology`
       on ((`away`.`aw_productiontasks`.`processingTechnologyID` =
            `away`.`aw_processingtechnology`.`id`))) join `away`.`aw_salesorderdetails`
      on ((`away`.`aw_productiontasks`.`saleOrderID` = `away`.`aw_salesorderdetails`.`id`)));

-- comment on column aw_detailedproductiontask.id not supported: 任务编号

-- comment on column aw_detailedproductiontask.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_detailedproductiontask.serialNum not supported: 生产任务序号

-- comment on column aw_detailedproductiontask.outsourced not supported: 外协

-- comment on column aw_detailedproductiontask.notes not supported: 备注

-- comment on column aw_detailedproductiontask.status not supported: 任务状态

-- comment on column aw_detailedproductiontask.processingTechnologyID not supported: 工艺编号

-- comment on column aw_detailedproductiontask.founder not supported: 创建人

-- comment on column aw_detailedproductiontask.saleOrderID not supported: 销售订单编号

-- comment on column aw_detailedproductiontask.createTime not supported: 销售单创建日期

-- comment on column aw_detailedproductiontask.createUserName not supported: 创建人

-- comment on column aw_detailedproductiontask.orderDate not supported: 下单日期

-- comment on column aw_detailedproductiontask.number not supported: 需求数量#要求大于0#

-- comment on column aw_detailedproductiontask.requiredDeliveryTime not supported: 要求交期#时间要晚于当前日期#

-- comment on column aw_detailedproductiontask.iscustomersuppliedmaterials not supported: 客供材料否

-- comment on column aw_detailedproductiontask.customersuppliedmaterialsID not supported: 客供材料编号

-- comment on column aw_detailedproductiontask.state not supported: 当前订单状态#0为未发布 1为发布 2为暂停 3为完成 4为取消#

-- comment on column aw_detailedproductiontask.nameAbbrevation not supported: 实体简称

-- comment on column aw_detailedproductiontask.productName not supported: 产品名称

