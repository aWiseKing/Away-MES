create definer = root@localhost view v1 as
select `away`.`aw_localmaterialwarehousing`.`id`                  AS `id`,
       `away`.`aw_localmaterialwarehousing`.`receiptQuantity`     AS `receiptQuantity`,
       `away`.`aw_localmaterialwarehousing`.`sampleURL`           AS `localmaterialwarehousingSampleURL`,
       `away`.`aw_localmaterialwarehousing`.`notes`               AS `localmaterialwarehousingNotes`,
       `away`.`aw_warehousing`.`warehouseEntryID`                 AS `warehouseEntryID`,
       `away`.`aw_warehousing`.`warehousingDate`                  AS `warehousingDate`,
       `away`.`aw_warehousing`.`creator`                          AS `creator`,
       `away`.`aw_warehousing`.`acceptedBy`                       AS `acceptedBy`,
       `away`.`aw_warehousing`.`warehouseKeeper`                  AS `warehouseKeeper`,
       `away`.`aw_warehousing`.`operator`                         AS `operator`,
       `away`.`aw_warehousing`.`notes`                            AS `warehousingNotes`,
       `away`.`aw_receiptinvoice`.`receiptInvoiceID`              AS `receiptInvoiceID`,
       `away`.`aw_receiptinvoice`.`invoiceType`                   AS `invoiceType`,
       `away`.`aw_receiptinvoice`.`invoiceTaxRate`                AS `invoiceTaxRate`,
       `away`.`aw_receiptinvoice`.`purchaseUnitPriceExcludingTax` AS `purchaseUnitPriceExcludingTax`,
       `away`.`aw_material`.`id`                                  AS `materialID`,
       `away`.`aw_material`.`materialDensity`                     AS `materialDensity`,
       `away`.`aw_material`.`name`                                AS `materialName`,
       `away`.`aw_material`.`notes`                               AS `materialnotes`,
       `away`.`aw_materialsubscription`.`materialSubscription`    AS `materialSubscription`,
       `away`.`aw_materialsubscription`.`subscriptionQuantity`    AS `subscriptionQuantity`,
       `away`.`aw_materialsubscription`.`requiredDate`            AS `requiredDate`,
       `away`.`aw_materialsubscription`.`sampleURL`               AS `materialsubscriptionSampleURL`,
       `away`.`aw_materialsubscription`.`note`                    AS `materialsubscriptionNote`
from ((((`away`.`aw_localmaterialwarehousing` join `away`.`aw_warehousing`
         on ((`away`.`aw_localmaterialwarehousing`.`id` =
              `away`.`aw_warehousing`.`warehouseEntryID`))) join `away`.`aw_receiptinvoice`
        on ((`away`.`aw_localmaterialwarehousing`.`id` =
             `away`.`aw_receiptinvoice`.`receiptInvoiceID`))) join `away`.`aw_material`
       on ((`away`.`aw_localmaterialwarehousing`.`id` = `away`.`aw_material`.`id`))) join `away`.`aw_materialsubscription`
      on ((`away`.`aw_localmaterialwarehousing`.`id` = `away`.`aw_materialsubscription`.`materialSubscription`)));

-- comment on column v1.id not supported: id

-- comment on column v1.receiptQuantity not supported: 入库数量

-- comment on column v1.localmaterialwarehousingSampleURL not supported: 附样

-- comment on column v1.localmaterialwarehousingNotes not supported: 备注

-- comment on column v1.warehouseEntryID not supported: 入库单编号

-- comment on column v1.warehousingDate not supported: 入库日期

-- comment on column v1.creator not supported: 制单人

-- comment on column v1.acceptedBy not supported: 验收人

-- comment on column v1.warehouseKeeper not supported: 库管员

-- comment on column v1.operator not supported: 经办人

-- comment on column v1.warehousingNotes not supported: 备注

-- comment on column v1.receiptInvoiceID not supported: 入库发票编号

-- comment on column v1.invoiceType not supported: 发票类型

-- comment on column v1.invoiceTaxRate not supported: 发票税率

-- comment on column v1.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column v1.materialID not supported: 材料编号

-- comment on column v1.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column v1.materialName not supported: 材料名称

-- comment on column v1.materialnotes not supported: 备注信息

-- comment on column v1.materialSubscription not supported: 申购材料编号

-- comment on column v1.subscriptionQuantity not supported: 申购数量

-- comment on column v1.requiredDate not supported: 需用日期

-- comment on column v1.materialsubscriptionSampleURL not supported: 附样

-- comment on column v1.materialsubscriptionNote not supported: 备注

