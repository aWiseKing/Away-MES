create definer = root@localhost view materialwarehousingdetailed2 as
select `away`.`aw_warehousing`.`warehouseEntryID`                   AS `warehouseEntryID`,
       `away`.`aw_warehousing`.`warehousingDate`                    AS `warehousingDate`,
       `away`.`aw_warehousing`.`creator`                            AS `creator`,
       `away`.`aw_warehousing`.`warehouseKeeper`                    AS `warehouseKeeper`,
       `away`.`aw_warehousing`.`operator`                           AS `operator`,
       `away`.`aw_warehousing`.`notes`                              AS `notes`,
       `away`.`aw_localmaterialwarehousing`.`receiptQuantity`       AS `receiptQuantity`,
       `away`.`aw_localmaterialwarehousing`.`sampleURL`             AS `sampleURL`,
       `away`.`aw_basicinformationofmaterials`.`name`               AS `name`,
       `away`.`aw_basicinformationofmaterials`.`typeName`           AS `typeName`,
       `away`.`aw_basicinformationofmaterials`.`specificationsType` AS `specificationsType`,
       `away`.`aw_basicinformationofmaterials`.`specificationModel` AS `specificationModel`,
       `away`.`aw_basicinformationofmaterials`.`materialDensity`    AS `materialDensity`,
       `away`.`aw_receiptinvoice`.`invoiceTaxRate`                  AS `invoiceTaxRate`,
       `away`.`aw_receiptinvoice`.`invoiceType`                     AS `invoiceType`,
       `away`.`aw_receiptinvoice`.`purchaseUnitPriceExcludingTax`   AS `purchaseUnitPriceExcludingTax`,
       `away`.`aw_receiptinvoice`.`purchaseUnitPriceIncludingTax`   AS `purchaseUnitPriceIncludingTax`,
       `away`.`aw_materialsubscription`.`subscriptionQuantity`      AS `subscriptionQuantity`,
       `away`.`aw_materialsubscription`.`materialSubscription`      AS `materialSubscription`
from ((((`away`.`aw_warehousing` join `away`.`aw_localmaterialwarehousing`
         on ((`away`.`aw_warehousing`.`warehouseEntryID` =
              `away`.`aw_localmaterialwarehousing`.`warehouseEntryID`))) join `away`.`aw_basicinformationofmaterials`
        on ((`away`.`aw_localmaterialwarehousing`.`materialID` =
             `away`.`aw_basicinformationofmaterials`.`id`))) join `away`.`aw_receiptinvoice`
       on ((`away`.`aw_receiptinvoice`.`receiptInvoiceID` =
            `away`.`aw_localmaterialwarehousing`.`receiptInvoiceID`))) join `away`.`aw_materialsubscription`
      on (((`away`.`aw_materialsubscription`.`materialSubscription` = `away`.`aw_localmaterialwarehousing`.`id`) and
           (`away`.`aw_materialsubscription`.`materialSubscription` = `away`.`aw_basicinformationofmaterials`.`id`))));

-- comment on column materialwarehousingdetailed2.warehouseEntryID not supported: 入库单编号

-- comment on column materialwarehousingdetailed2.warehousingDate not supported: 入库日期

-- comment on column materialwarehousingdetailed2.creator not supported: 制单人

-- comment on column materialwarehousingdetailed2.warehouseKeeper not supported: 库管员

-- comment on column materialwarehousingdetailed2.operator not supported: 经办人

-- comment on column materialwarehousingdetailed2.notes not supported: 备注

-- comment on column materialwarehousingdetailed2.receiptQuantity not supported: 入库数量

-- comment on column materialwarehousingdetailed2.sampleURL not supported: 附样

-- comment on column materialwarehousingdetailed2.name not supported: 材料名称

-- comment on column materialwarehousingdetailed2.typeName not supported: 类别名称

-- comment on column materialwarehousingdetailed2.specificationsType not supported: 规格类型

-- comment on column materialwarehousingdetailed2.specificationModel not supported: 规格型号

-- comment on column materialwarehousingdetailed2.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column materialwarehousingdetailed2.invoiceTaxRate not supported: 发票税率

-- comment on column materialwarehousingdetailed2.invoiceType not supported: 发票类型

-- comment on column materialwarehousingdetailed2.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column materialwarehousingdetailed2.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column materialwarehousingdetailed2.subscriptionQuantity not supported: 申购数量

-- comment on column materialwarehousingdetailed2.materialSubscription not supported: 申购材料编号

