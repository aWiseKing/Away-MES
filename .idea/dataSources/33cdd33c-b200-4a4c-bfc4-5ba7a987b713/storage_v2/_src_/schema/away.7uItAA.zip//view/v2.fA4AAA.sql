create definer = root@localhost view v2 as
select `away`.`aw_warehousing`.`warehouseEntryID` AS `warehousingID`,
       `away`.`aw_warehousing`.`warehousingDate`  AS `warehousingDate`,
       `away`.`aw_warehousing`.`creator`          AS `creator`,
       `away`.`aw_warehousing`.`acceptedBy`       AS `acceptedBy`,
       `away`.`aw_warehousing`.`warehouseKeeper`  AS `warehouseKeeper`,
       `away`.`aw_warehousing`.`operator`         AS `operator`
from ((`away`.`aw_localmaterialwarehousing` join `away`.`aw_warehousing`
       on ((`away`.`aw_localmaterialwarehousing`.`warehouseEntryID` =
            `away`.`aw_warehousing`.`warehouseEntryID`))) join ((`away`.`aw_material` join `away`.`aw_specifications`
                                                                 on ((`away`.`aw_material`.`specificationsID` =
                                                                      `away`.`aw_specifications`.`id`))) join `away`.`aw_materialclassification`
                                                                on ((`away`.`aw_material`.`typeID` =
                                                                     `away`.`aw_materialclassification`.`id`)))
      on ((`away`.`aw_localmaterialwarehousing`.`materialID` = `away`.`aw_localmaterialwarehousing`.`materialID`)));

-- comment on column v2.warehousingID not supported: 入库单编号

-- comment on column v2.warehousingDate not supported: 入库日期

-- comment on column v2.creator not supported: 制单人

-- comment on column v2.acceptedBy not supported: 验收人

-- comment on column v2.warehouseKeeper not supported: 库管员

-- comment on column v2.operator not supported: 经办人

