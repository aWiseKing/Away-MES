create
    definer = root@localhost procedure getjiecheng(IN n int) deterministic
begin
    declare cont int default 1;
        method:loop
            if n<=1 then
                leave method;
            end if;
            set cont=cont*n;
            set n=n-1;
        end loop;
    select  cont;
end;

