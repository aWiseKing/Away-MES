create
    definer = root@localhost function jiecheng(n int) returns int deterministic
begin

    declare itep int  default 1;
    declare i int default 1;
    while i<=n do
        set itep=itep*i;
        set i=i+1;

        end while ;
    return itep;
end;

