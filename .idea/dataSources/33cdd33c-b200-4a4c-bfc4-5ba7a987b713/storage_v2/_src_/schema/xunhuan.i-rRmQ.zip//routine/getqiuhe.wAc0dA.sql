create
    definer = root@localhost function getqiuhe(num int) returns int deterministic
begin
    declare cont int default 0;
    declare i  int default 1 ;
    while i<num do
        set cont=cont+i;
        set i =i+1;
        end while;
    return cont;
end;

