create
    definer = root@localhost function Numch(num int) returns varchar(10) deterministic
begin
    declare itep varchar(10);

    if num%2=0 then  set itep='偶数';
      elseif num%2=1 then set itep='奇数';
      else set itep='数字错误';

      end if;
    return itep;


end;

