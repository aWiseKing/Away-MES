create
    definer = root@localhost function getweek(day varchar(10)) returns varchar(10) deterministic
begin
    declare week varchar(10);
--
    case day
        when 1 then set week='monday';
        when 2 then set week='tuesday';
        when 3 then set week='wednesday';
        when 4 then set week='thursday';
        when 5 then set week='friday';
        when 6 then set week='saturday';
        when 7 then set week='sunday';
        when 8 then set week='weekend';
        else set week='无法判断';

        end case ;

    return week;
end;

