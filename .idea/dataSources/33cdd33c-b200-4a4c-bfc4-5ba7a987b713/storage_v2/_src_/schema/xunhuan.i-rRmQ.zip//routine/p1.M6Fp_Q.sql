create
    definer = root@localhost procedure p1(IN n int) deterministic
begin
    declare total int  default 0;
    sum:loop

        if n<=0 then
            leave sum;
        end if;

        set total=total+n;
        set n=n-1;
    end loop sum ;
    select total;



end;

