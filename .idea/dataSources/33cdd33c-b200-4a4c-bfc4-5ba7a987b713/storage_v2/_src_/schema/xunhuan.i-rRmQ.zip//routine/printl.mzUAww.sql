create
    definer = root@localhost function printl(n int) returns int deterministic
begin

    declare res int default 0;

 while n>0 do
     set res=res+n;
     set n=n-1;
     end while ;

    return res;

end;

