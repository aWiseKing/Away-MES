create
    definer = root@localhost procedure p2(IN n int) deterministic
begin
    declare total int  default 0;
    sum:loop

        if n<=0 then
            leave sum;
        end if;


#遇到奇数就下一次循环
        if n%2=1 then
              set n=n-1;   # 这一步很细节，如果n不减1，那么当跳过循环后下面的语句（ set n=n-1;） 也不会执行，那么下一次送来的还是 奇数

            iterate sum;
        end if ;

        set total=total+n;
        set n=n-1;
    end loop sum ;
    select total;


end;

