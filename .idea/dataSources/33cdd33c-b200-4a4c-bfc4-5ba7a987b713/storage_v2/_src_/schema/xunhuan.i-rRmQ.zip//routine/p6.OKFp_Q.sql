create
    definer = root@localhost procedure p6(IN i int) deterministic
begin
declare count int default 0;
    repeat
    set count=count+i;
    set i=i-1;
    until  i<=0
    end repeat;
select count;
end;

