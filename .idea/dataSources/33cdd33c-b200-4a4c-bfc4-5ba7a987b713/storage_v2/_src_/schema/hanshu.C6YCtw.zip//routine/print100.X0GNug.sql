create
    definer = root@localhost function print100() returns int
begin

#deterministic
       return 5;

end;

