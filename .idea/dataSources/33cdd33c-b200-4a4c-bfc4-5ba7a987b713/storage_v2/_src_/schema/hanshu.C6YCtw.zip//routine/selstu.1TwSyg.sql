create
    definer = root@localhost function selstu() returns varchar(1000)
begin
    return (select name from f1 where name='小王');
end;

