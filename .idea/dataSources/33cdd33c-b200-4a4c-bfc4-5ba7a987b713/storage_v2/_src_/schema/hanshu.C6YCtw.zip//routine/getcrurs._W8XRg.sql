create
    definer = root@localhost function getcrurs(xid varchar(10)) returns varchar(100) deterministic
begin
    return (select name from student where id=xid);

end;

