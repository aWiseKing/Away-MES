create
    definer = root@localhost function twosum(a int, b int) returns int
begin
    return(a+b);
end;

