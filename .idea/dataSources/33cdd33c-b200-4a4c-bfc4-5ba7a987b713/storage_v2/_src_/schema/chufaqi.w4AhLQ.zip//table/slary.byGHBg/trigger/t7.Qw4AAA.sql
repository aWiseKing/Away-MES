create definer = root@localhost trigger t7
    after insert
    on slary
    for each row
begin
        set@res=@res+NEW.gz;
    end;

