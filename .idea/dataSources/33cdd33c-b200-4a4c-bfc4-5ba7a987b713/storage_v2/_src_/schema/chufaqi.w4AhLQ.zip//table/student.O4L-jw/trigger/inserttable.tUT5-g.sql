create definer = root@localhost trigger inserttable
    after insert
    on student
    for each row
begin
        delete from teachr where teachr.id=10;
    end;

