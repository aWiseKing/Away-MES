create definer = root@localhost trigger a1
    after delete
    on salary1
    for each row
begin
       set @res1= @res1-old.gz;
    end;

