create definer = root@localhost trigger t1
    after insert
    on aa
    for each row
begin
        delete from bb where bb.bid=10;
    end;

