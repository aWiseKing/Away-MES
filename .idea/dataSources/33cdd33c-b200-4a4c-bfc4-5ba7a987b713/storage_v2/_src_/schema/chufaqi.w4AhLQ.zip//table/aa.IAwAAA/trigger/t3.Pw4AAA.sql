create definer = root@localhost trigger t3
    after delete
    on aa
    for each row
begin
        insert into bb values (40,'人文社科系');
     end;

