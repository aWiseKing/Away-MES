create definer = root@localhost trigger t2
    after update
    on aa
    for each row
begin
        update bb set depment='管理系' where bid=20;
     end;

