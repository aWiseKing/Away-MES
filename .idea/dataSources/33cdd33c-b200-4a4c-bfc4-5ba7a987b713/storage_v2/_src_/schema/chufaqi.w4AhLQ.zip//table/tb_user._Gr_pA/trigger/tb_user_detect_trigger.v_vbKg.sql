create definer = root@localhost trigger tb_user_detect_trigger
    after delete
    on tb_user
    for each row
begin
        insert into user_logs(id, operaation, operate_time, operate_id,operate_params) values
         (null,'delete',now(),OLD.id,
          concat('删除之前的数据:id为',old.id,',name=',OLD.name,',emil=',OLD.email,'profession',OLD.profession));
    end;

