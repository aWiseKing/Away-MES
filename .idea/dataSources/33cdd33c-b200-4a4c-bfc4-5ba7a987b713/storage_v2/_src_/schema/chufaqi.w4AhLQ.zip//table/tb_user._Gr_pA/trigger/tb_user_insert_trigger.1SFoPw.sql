create definer = root@localhost trigger tb_user_insert_trigger
    after insert
    on tb_user
    for each row
begin
        insert into user_logs(id, operaation, operate_time, operate_id,operate_params) values
         (null,'insert',now(),NEW.id,concat('插入的数据id为:',NEW.id,',name=',NEW.name,',emil=',new.email,'profession',new.profession));
    end;

