create definer = root@localhost trigger tb_user_update_trigger
    after update
    on tb_user
    for each row
begin
        insert into user_logs(id, operaation, operate_time, operate_id,operate_params) values
         (null,'update',now(),NEW.id,
          concat('更新之前的数据:id为',old.id,',name=',OLD.name,',emil=',OLD.email,'profession',OLD.profession,
              '|更新的数据:id为',NEW.id,',name=',NEW.name,',emil=',new.email,'profession',new.profession));
    end;

