create definer = away@`%` view aw_DetailProductOutbound as
select `away`.`aw_ProductOutbound`.`id`                     AS `id`,
       `away`.`aw_ProductOutbound`.`deliveryNoteID`         AS `deliveryNoteID`,
       `away`.`aw_ProductOutbound`.`productID`              AS `productID`,
       `away`.`aw_product`.`name`                           AS `productname`,
       `away`.`aw_ProductOutbound`.`shippingInspectionID`   AS `shippingInspectionID`,
       `away`.`aw_ShippingInspection`.`shipmentQuantity`    AS `shipmentQuantity`,
       `away`.`aw_ShippingInspection`.`detectionQuantity`   AS `detectionQuantity`,
       `away`.`aw_ShippingInspection`.`qualifiedQuantity`   AS `qualifiedQuantity`,
       `away`.`aw_ShippingInspection`.`unqualifiedQuantity` AS `unqualifiedQuantity`,
       `away`.`aw_ShippingInspection`.`testResult`          AS `testResult`,
       `away`.`aw_ShippingInspection`.`testDate`            AS `testDate`,
       `away`.`aw_ShippingInspection`.`testingPersonnel`    AS `testingPersonnel`,
       `away`.`aw_ProductOutbound`.`receiptQuantity`        AS `receiptQuantity`,
       `away`.`aw_ProductOutbound`.`contractID`             AS `contractID`,
       `away`.`aw_partner`.`name`                           AS `customname`
from (((`away`.`aw_ProductOutbound` join `away`.`aw_product`
        on ((`away`.`aw_ProductOutbound`.`productID` = `away`.`aw_product`.`id`))) join `away`.`aw_ShippingInspection`
       on (((`away`.`aw_ProductOutbound`.`shippingInspectionID` = `away`.`aw_ShippingInspection`.`id`) and
            (`away`.`aw_product`.`id` = `away`.`aw_ShippingInspection`.`productID`)))) join `away`.`aw_partner`
      on ((`away`.`aw_ShippingInspection`.`contractID` = `away`.`aw_partner`.`id`)));

-- comment on column aw_DetailProductOutbound.id not supported: id

-- comment on column aw_DetailProductOutbound.deliveryNoteID not supported: 出库单编号

-- comment on column aw_DetailProductOutbound.productID not supported: 产品图号

-- comment on column aw_DetailProductOutbound.productname not supported: 产品名称

-- comment on column aw_DetailProductOutbound.shippingInspectionID not supported: 出货检验编号

-- comment on column aw_DetailProductOutbound.shipmentQuantity not supported: 出货数量

-- comment on column aw_DetailProductOutbound.detectionQuantity not supported: 检测数量

-- comment on column aw_DetailProductOutbound.qualifiedQuantity not supported: 合格数量

-- comment on column aw_DetailProductOutbound.unqualifiedQuantity not supported: 不合格数量

-- comment on column aw_DetailProductOutbound.testResult not supported: 检测结果

-- comment on column aw_DetailProductOutbound.testDate not supported: 检测日期

-- comment on column aw_DetailProductOutbound.testingPersonnel not supported: 检测人员

-- comment on column aw_DetailProductOutbound.receiptQuantity not supported: 出库数量

-- comment on column aw_DetailProductOutbound.contractID not supported: 客户编号

-- comment on column aw_DetailProductOutbound.customname not supported: 实体姓名

