create definer = away@`%` view materialWarehousingDetailed as
select `away`.`aw_warehousing`.`warehouseEntryID`             AS `warehouseEntryID`,
       `away`.`aw_warehousing`.`warehousingDate`              AS `warehousingDate`,
       `away`.`aw_warehousing`.`creator`                      AS `creator`,
       `away`.`aw_warehousing`.`warehouseKeeper`              AS `warehouseKeeper`,
       `away`.`aw_warehousing`.`operator`                     AS `operator`,
       `away`.`aw_warehousing`.`notes`                        AS `notes`,
       `away`.`aw_localmaterialwarehousing`.`receiptQuantity` AS `receiptQuantity`,
       `away`.`aw_localmaterialwarehousing`.`sampleURL`       AS `sampleURL`,
       `aw_basicinformationofmaterials`.`name`                AS `name`,
       `aw_basicinformationofmaterials`.`typeName`            AS `typeName`,
       `aw_basicinformationofmaterials`.`specificationsType`  AS `specificationsType`,
       `aw_basicinformationofmaterials`.`specificationModel`  AS `specificationModel`,
       `aw_basicinformationofmaterials`.`materialDensity`     AS `materialDensity`
from ((`away`.`aw_warehousing` join `away`.`aw_localmaterialwarehousing`
       on ((`away`.`aw_warehousing`.`warehouseEntryID` =
            `away`.`aw_localmaterialwarehousing`.`warehouseEntryID`))) join `away`.`aw_basicinformationofmaterials`
      on ((`away`.`aw_localmaterialwarehousing`.`materialID` = `aw_basicinformationofmaterials`.`id`)));

-- comment on column materialWarehousingDetailed.warehouseEntryID not supported: 入库单编号

-- comment on column materialWarehousingDetailed.warehousingDate not supported: 入库日期

-- comment on column materialWarehousingDetailed.creator not supported: 制单人

-- comment on column materialWarehousingDetailed.warehouseKeeper not supported: 库管员

-- comment on column materialWarehousingDetailed.operator not supported: 经办人

-- comment on column materialWarehousingDetailed.notes not supported: 备注

-- comment on column materialWarehousingDetailed.receiptQuantity not supported: 入库数量

-- comment on column materialWarehousingDetailed.sampleURL not supported: 附样

-- comment on column materialWarehousingDetailed.name not supported: 材料名称

-- comment on column materialWarehousingDetailed.typeName not supported: 类别名称

-- comment on column materialWarehousingDetailed.specificationsType not supported: 规格类型

-- comment on column materialWarehousingDetailed.specificationModel not supported: 规格型号

-- comment on column materialWarehousingDetailed.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

