create definer = away@`%` view materialWarehousingDetailed as
select `away`.`aw_warehousing`.`warehouseEntryID`                 AS `warehouseEntryID`,
       `away`.`aw_localmaterialwarehousing`.`id`                  AS `localmaterialwarehousingID`,
       `away`.`aw_materialsubscription`.`subscriptionQuantity`    AS `subscriptionQuantity`,
       `aw_basicinformationofmaterials`.`name`                    AS `name`,
       `aw_basicinformationofmaterials`.`typeName`                AS `typeName`,
       `aw_basicinformationofmaterials`.`specificationsType`      AS `specificationsType`,
       `aw_basicinformationofmaterials`.`specificationModel`      AS `specificationModel`,
       `aw_basicinformationofmaterials`.`materialDensity`         AS `materialDensity`,
       `away`.`aw_receiptinvoice`.`invoiceTaxRate`                AS `invoiceTaxRate`,
       `away`.`aw_receiptinvoice`.`invoiceType`                   AS `invoiceType`,
       `away`.`aw_receiptinvoice`.`purchaseUnitPriceExcludingTax` AS `purchaseUnitPriceExcludingTax`,
       `away`.`aw_receiptinvoice`.`purchaseUnitPriceIncludingTax` AS `purchaseUnitPriceIncludingTax`,
       `away`.`aw_materialsubscription`.`subscribeID`             AS `subscribeID`,
       `away`.`aw_localmaterialwarehousing`.`sampleURL`           AS `sampleURL`
from ((((`away`.`aw_localmaterialwarehousing` join `away`.`aw_basicinformationofmaterials`
         on ((`away`.`aw_localmaterialwarehousing`.`materialID` =
              `aw_basicinformationofmaterials`.`id`))) join `away`.`aw_receiptinvoice`
        on ((`away`.`aw_localmaterialwarehousing`.`receiptInvoiceID` =
             `away`.`aw_receiptinvoice`.`receiptInvoiceID`))) join `away`.`aw_materialsubscription`
       on ((`away`.`aw_localmaterialwarehousing`.`materialSubscription` =
            `away`.`aw_materialsubscription`.`materialSubscription`))) join `away`.`aw_warehousing`
      on ((`away`.`aw_localmaterialwarehousing`.`warehouseEntryID` = `away`.`aw_warehousing`.`warehouseEntryID`)));

-- comment on column materialWarehousingDetailed.warehouseEntryID not supported: 入库单编号

-- comment on column materialWarehousingDetailed.localmaterialwarehousingID not supported: id

-- comment on column materialWarehousingDetailed.subscriptionQuantity not supported: 申购数量

-- comment on column materialWarehousingDetailed.name not supported: 材料名称

-- comment on column materialWarehousingDetailed.typeName not supported: 类别名称

-- comment on column materialWarehousingDetailed.specificationsType not supported: 规格类型

-- comment on column materialWarehousingDetailed.specificationModel not supported: 规格型号

-- comment on column materialWarehousingDetailed.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column materialWarehousingDetailed.invoiceTaxRate not supported: 发票税率

-- comment on column materialWarehousingDetailed.invoiceType not supported: 发票类型

-- comment on column materialWarehousingDetailed.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column materialWarehousingDetailed.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column materialWarehousingDetailed.subscribeID not supported: 申购单编号

-- comment on column materialWarehousingDetailed.sampleURL not supported: 附样

