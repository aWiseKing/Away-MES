create definer = away@`%` view aw_DetailedRealTimeInventoryOfMaterials as
select `away`.`aw_localmaterials`.`id`                       AS `id`,
       `away`.`aw_localmaterials`.`materialID`               AS `materialID`,
       `away`.`aw_localmaterials`.`number`                   AS `number`,
       `away`.`aw_localmaterials`.`weight`                   AS `weight`,
       `aw_BasicInformationOfMaterials`.`name`               AS `name`,
       `aw_BasicInformationOfMaterials`.`typeName`           AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType` AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel` AS `specificationModel`,
       `aw_BasicInformationOfMaterials`.`materialDensity`    AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`notes`              AS `notes`
from (`away`.`aw_BasicInformationOfMaterials` join `away`.`aw_localmaterials`
      on ((`aw_BasicInformationOfMaterials`.`id` = `away`.`aw_localmaterials`.`materialID`)));

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.id not supported: 材料库存id

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.materialID not supported: 材料基本信息id

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.number not supported: 材料库存数量

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.weight not supported: 材料库存重量

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.name not supported: 材料名称

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.typeName not supported: 类别名称

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.specificationsType not supported: 规格类型

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.specificationModel not supported: 规格型号

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_DetailedRealTimeInventoryOfMaterials.notes not supported: 备注信息

