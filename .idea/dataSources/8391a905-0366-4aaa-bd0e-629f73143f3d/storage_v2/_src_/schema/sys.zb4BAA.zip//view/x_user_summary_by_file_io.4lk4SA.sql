create definer = `mysql.sys`@localhost view x$user_summary_by_file_io as
select if(isnull(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`), 'background',
          `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)            AS `user`,
       sum(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`COUNT_STAR`)     AS `ios`,
       sum(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`) AS `io_latency`
from `performance_schema`.`events_waits_summary_by_user_by_event_name`
where (`performance_schema`.`events_waits_summary_by_user_by_event_name`.`EVENT_NAME` like 'wait/io/file/%')
group by if(isnull(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`), 'background',
            `performance_schema`.`events_waits_summary_by_user_by_event_name`.`USER`)
order by sum(`performance_schema`.`events_waits_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`) desc;

