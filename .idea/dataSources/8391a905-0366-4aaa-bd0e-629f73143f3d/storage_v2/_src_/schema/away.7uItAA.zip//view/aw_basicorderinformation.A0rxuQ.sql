create definer = root@`%` view aw_basicorderinformation as
select `away`.`aw_saleorder`.`id`     AS `id`,
       `away`.`aw_saleorder`.`number` AS `number`,
       `away`.`aw_partner`.`name`     AS `name`,
       `away`.`aw_contract`.`money`   AS `money`,
       `away`.`aw_product`.`name`     AS `productName`
from (((`away`.`aw_saleorder` join `away`.`aw_partner`
        on ((`away`.`aw_saleorder`.`customerID` = `away`.`aw_partner`.`id`))) join `away`.`aw_product`
       on ((`away`.`aw_saleorder`.`productID` = `away`.`aw_product`.`id`))) join `away`.`aw_contract`
      on ((`away`.`aw_saleorder`.`contractID` = `away`.`aw_contract`.`id`)));

-- comment on column aw_basicorderinformation.id not supported: 订单id#日期+编号#

-- comment on column aw_basicorderinformation.number not supported: 需求数量#要求大于0#

-- comment on column aw_basicorderinformation.name not supported: 实体姓名

-- comment on column aw_basicorderinformation.money not supported: 合同金额

-- comment on column aw_basicorderinformation.productName not supported: 产品名称

