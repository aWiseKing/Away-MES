-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单', '2029', '1', 'productiontasklist', 'produce/productiontasklist/index', 1, 0, 'C', '0', '0', 'produce:productiontasklist:list', '#', 'admin', sysdate(), '', null, '生产任务单菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'produce:productiontasklist:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'produce:productiontasklist:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'produce:productiontasklist:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'produce:productiontasklist:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('生产任务单导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'produce:productiontasklist:export',       '#', 'admin', sysdate(), '', null, '');