package com.awise.produce.service;

import java.util.List;
import com.awise.produce.domain.AwProcessingprocess;

/**
 * 加工工序信息
存储加工过程中每道工序的情况Service接口
 * 
 * @author awise
 * @date 2023-08-21
 */
public interface IAwProcessingprocessService 
{
    /**
     * 查询加工工序信息
存储加工过程中每道工序的情况
     * 
     * @param id 加工工序信息
存储加工过程中每道工序的情况主键
     * @return 加工工序信息
存储加工过程中每道工序的情况
     */
    public AwProcessingprocess selectAwProcessingprocessById(Long id);

    /**
     * 查询加工工序信息
存储加工过程中每道工序的情况列表
     * 
     * @param awProcessingprocess 加工工序信息
存储加工过程中每道工序的情况
     * @return 加工工序信息
存储加工过程中每道工序的情况集合
     */
    public List<AwProcessingprocess> selectAwProcessingprocessList(AwProcessingprocess awProcessingprocess);

    /**
     * 新增加工工序信息
存储加工过程中每道工序的情况
     * 
     * @param awProcessingprocess 加工工序信息
存储加工过程中每道工序的情况
     * @return 结果
     */
    public int insertAwProcessingprocess(AwProcessingprocess awProcessingprocess);

    /**
     * 修改加工工序信息
存储加工过程中每道工序的情况
     * 
     * @param awProcessingprocess 加工工序信息
存储加工过程中每道工序的情况
     * @return 结果
     */
    public int updateAwProcessingprocess(AwProcessingprocess awProcessingprocess);

    /**
     * 批量删除加工工序信息
存储加工过程中每道工序的情况
     * 
     * @param ids 需要删除的加工工序信息
存储加工过程中每道工序的情况主键集合
     * @return 结果
     */
    public int deleteAwProcessingprocessByIds(Long[] ids);

    /**
     * 删除加工工序信息
存储加工过程中每道工序的情况信息
     * 
     * @param id 加工工序信息
存储加工过程中每道工序的情况主键
     * @return 结果
     */
    public int deleteAwProcessingprocessById(Long id);
}
