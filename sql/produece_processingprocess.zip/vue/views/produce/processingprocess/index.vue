<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="加工工艺信息" prop="processingTechnologyID">
        <el-input
          v-model="queryParams.processingTechnologyID"
          placeholder="请输入加工工艺信息"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="同一生产任务下工序序号" prop="number">
        <el-input
          v-model="queryParams.number"
          placeholder="请输入同一生产任务下工序序号"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="工序名称" prop="name">
        <el-input
          v-model="queryParams.name"
          placeholder="请输入工序名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="工序简图URL" prop="diagramURL">
        <el-input
          v-model="queryParams.diagramURL"
          placeholder="请输入工序简图URL"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="所用工装" prop="usedTooling">
        <el-input
          v-model="queryParams.usedTooling"
          placeholder="请输入所用工装"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="准备工时" prop="preparationHours">
        <el-input
          v-model="queryParams.preparationHours"
          placeholder="请输入准备工时"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="单件工时" prop="taktTime">
        <el-input
          v-model="queryParams.taktTime"
          placeholder="请输入单件工时"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="工时成本" prop="laborCost">
        <el-input
          v-model="queryParams.laborCost"
          placeholder="请输入工时成本"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="工序外协#0为不外协1为外协#" prop="outsourcing">
        <el-input
          v-model="queryParams.outsourcing"
          placeholder="请输入工序外协#0为不外协1为外协#"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['produce:processingprocess:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['produce:processingprocess:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['produce:processingprocess:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['produce:processingprocess:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="processingprocessList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="工序编号" align="center" prop="id" />
      <el-table-column label="加工工艺信息" align="center" prop="processingTechnologyID" />
      <el-table-column label="同一生产任务下工序序号" align="center" prop="number" />
      <el-table-column label="工序名称" align="center" prop="name" />
      <el-table-column label="工序内容" align="center" prop="content" />
      <el-table-column label="工序简图URL" align="center" prop="diagramURL" />
      <el-table-column label="所用工装" align="center" prop="usedTooling" />
      <el-table-column label="准备工时" align="center" prop="preparationHours" />
      <el-table-column label="单件工时" align="center" prop="taktTime" />
      <el-table-column label="工时成本" align="center" prop="laborCost" />
      <el-table-column label="工序外协#0为不外协1为外协#" align="center" prop="outsourcing" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['produce:processingprocess:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['produce:processingprocess:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改加工工序信息
存储加工过程中每道工序的情况对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="加工工艺信息" prop="processingTechnologyID">
          <el-input v-model="form.processingTechnologyID" placeholder="请输入加工工艺信息" />
        </el-form-item>
        <el-form-item label="同一生产任务下工序序号" prop="number">
          <el-input v-model="form.number" placeholder="请输入同一生产任务下工序序号" />
        </el-form-item>
        <el-form-item label="工序名称" prop="name">
          <el-input v-model="form.name" placeholder="请输入工序名称" />
        </el-form-item>
        <el-form-item label="工序内容">
          <editor v-model="form.content" :min-height="192"/>
        </el-form-item>
        <el-form-item label="工序简图URL" prop="diagramURL">
          <el-input v-model="form.diagramURL" placeholder="请输入工序简图URL" />
        </el-form-item>
        <el-form-item label="所用工装" prop="usedTooling">
          <el-input v-model="form.usedTooling" placeholder="请输入所用工装" />
        </el-form-item>
        <el-form-item label="准备工时" prop="preparationHours">
          <el-input v-model="form.preparationHours" placeholder="请输入准备工时" />
        </el-form-item>
        <el-form-item label="单件工时" prop="taktTime">
          <el-input v-model="form.taktTime" placeholder="请输入单件工时" />
        </el-form-item>
        <el-form-item label="工时成本" prop="laborCost">
          <el-input v-model="form.laborCost" placeholder="请输入工时成本" />
        </el-form-item>
        <el-form-item label="工序外协#0为不外协1为外协#" prop="outsourcing">
          <el-input v-model="form.outsourcing" placeholder="请输入工序外协#0为不外协1为外协#" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listProcessingprocess, getProcessingprocess, delProcessingprocess, addProcessingprocess, updateProcessingprocess } from "@/api/produce/processingprocess";

export default {
  name: "Processingprocess",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 加工工序信息
存储加工过程中每道工序的情况表格数据
      processingprocessList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        processingTechnologyID: null,
        number: null,
        name: null,
        content: null,
        diagramURL: null,
        usedTooling: null,
        preparationHours: null,
        taktTime: null,
        laborCost: null,
        outsourcing: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        processingTechnologyID: [
          { required: true, message: "加工工艺信息不能为空", trigger: "blur" }
        ],
        number: [
          { required: true, message: "同一生产任务下工序序号不能为空", trigger: "blur" }
        ],
        name: [
          { required: true, message: "工序名称不能为空", trigger: "blur" }
        ],
        content: [
          { required: true, message: "工序内容不能为空", trigger: "blur" }
        ],
        usedTooling: [
          { required: true, message: "所用工装不能为空", trigger: "blur" }
        ],
        preparationHours: [
          { required: true, message: "准备工时不能为空", trigger: "blur" }
        ],
        taktTime: [
          { required: true, message: "单件工时不能为空", trigger: "blur" }
        ],
        laborCost: [
          { required: true, message: "工时成本不能为空", trigger: "blur" }
        ],
        outsourcing: [
          { required: true, message: "工序外协#0为不外协1为外协#不能为空", trigger: "blur" }
        ]
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询加工工序信息
存储加工过程中每道工序的情况列表 */
    getList() {
      this.loading = true;
      listProcessingprocess(this.queryParams).then(response => {
        this.processingprocessList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        processingTechnologyID: null,
        number: null,
        name: null,
        content: null,
        diagramURL: null,
        usedTooling: null,
        preparationHours: null,
        taktTime: null,
        laborCost: null,
        outsourcing: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.id)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加加工工序信息
存储加工过程中每道工序的情况";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids
      getProcessingprocess(id).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改加工工序信息
存储加工过程中每道工序的情况";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.id != null) {
            updateProcessingprocess(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addProcessingprocess(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal.confirm('是否确认删除加工工序信息
存储加工过程中每道工序的情况编号为"' + ids + '"的数据项？').then(function() {
        return delProcessingprocess(ids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('produce/processingprocess/export', {
        ...this.queryParams
      }, `processingprocess_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
