-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况', '2029', '1', 'processingprocess', 'produce/processingprocess/index', 1, 0, 'C', '0', '0', 'produce:processingprocess:list', '#', 'admin', sysdate(), '', null, '加工工序信息
存储加工过程中每道工序的情况菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'produce:processingprocess:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'produce:processingprocess:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'produce:processingprocess:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'produce:processingprocess:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('加工工序信息
存储加工过程中每道工序的情况导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'produce:processingprocess:export',       '#', 'admin', sysdate(), '', null, '');